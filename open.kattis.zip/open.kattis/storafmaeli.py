n = int(input())

if n%10 == 0:
    print("Jebb")
else:
    print("Neibb")
    