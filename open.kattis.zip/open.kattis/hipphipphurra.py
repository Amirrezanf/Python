name = str(input())
age = int(input())
for i in range(age):
    print("Hipp hipp hurra, " + name + "!")