n = int(input())
print(n/4)