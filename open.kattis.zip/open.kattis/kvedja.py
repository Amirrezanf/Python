string = str(input())
print("Kvedja,\n", string)