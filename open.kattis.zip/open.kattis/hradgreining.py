String = str(input())
if "COV" in String:
    print("Veikur!")
else:
    print("Ekki veikur!")