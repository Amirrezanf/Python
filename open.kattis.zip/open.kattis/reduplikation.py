a = str(input())
b = int(input())
print(a * b)