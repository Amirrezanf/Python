a = int(input())
1 <= a
b = int(input())
b <= 100
c = int(input())
720 <= c <= 1439

print(c - b - a)