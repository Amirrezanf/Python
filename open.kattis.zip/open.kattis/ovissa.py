string = input()

print(len(string))
