T = int(input())
K = int(input())
if T < K:
    print("FAKE NEWS!")

if T > K:
    print("MAGA!")

if T == K:
    print("WORLD WAR 3!")
    
    