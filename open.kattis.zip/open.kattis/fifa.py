n = int(input())
k = int(input())
0 <= n <= 1000
print( 2022 + n // k)