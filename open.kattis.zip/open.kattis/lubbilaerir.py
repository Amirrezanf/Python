string = str(input())
print(string[0])