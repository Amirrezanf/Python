
str1 = input("plz enter first string: ")
str2 = input("plz enter second string: ")
str1 = str1.lower()
str2 = str2.lower()

if(len(str1) == len(str2)):
    sorted1 = sorted(str1)
    sorted2 = sorted(str2)

    if(sorted1 == sorted2):
        print("both strings are anagram.")
    else:
        print("both strings are not anagram.")

else:
    print("both strings are not anagram.")

