inputs = input("plz enter values of list with space: ")
elements = inputs.split()
dict = {}

for element in elements:
    if element in dict:
        dict[element] += 1
    else:
        dict[element] = 1

print("number of repeats:")
for key, value in dict.items():
    print(key + ":" + str(value))
