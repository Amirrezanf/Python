row = int(input("plz enter row number: "))

for i in range(1, row + 1):
    print("*" * i)
