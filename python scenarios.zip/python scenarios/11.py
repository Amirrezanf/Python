
number = int(input("plz enter a number: "))
num_str = str(number)

reversed_str = num_str[::-1]

if num_str == reversed_str:
    print("the number is palindrome.")
else:
    print("the number is not palindrome!")
