inputs = input("plz enter values of list seprated with space: ")
elements = inputs.split()
dict = {}

for element in elements:
    if element in dict:
        dict[element] += 1
    else:
        dict[element] = 1

group = {}

for element, count in dict.items():
    if count in group:
        group[count].append(element)
    else:
        group[count] = [element]

for count, items in group.items():
    print("count " + str(count) + " : "+ str(items))
