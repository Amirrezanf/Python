input1 = input("plz enter values of first list with space: ")
list1 = input1.split()

input2 = input("plz enter values of second list with space: ")
list2 = input2.split()

temp = []
for element in list1:
    if element in list2 and element not in temp:
        temp.append(element)


if temp:
    print("common elements between 2 lists")
    for element in temp:
        print(element)
else:
    print("no common elements!")
