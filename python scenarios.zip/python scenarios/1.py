def sum(start, end):
    total = 0
    for number in range(start, end):
        if number % 2 == 0:
            total += number
    return total

result = sum(1, 100)
print("The sum of even numbers between 1 to 100 is", result)
