inputs = input("plz enter dictionary in this format:\n key:value and for next click space\n>>>")

dict = {}
pairs = inputs.split()
for pair in pairs:
    key, value = pair.split(":")
    dict[key.strip()] = value.strip()

reverse = {}
for key, value in dict.items():
    reverse[value] = key

print("reversed dictionary:")
print(reverse)
