n = int(input("plz enter a number: "))
if n < 0:
    print("plz enter a positive number!")
elif n == 0:
    print("the fibonacci in zero sequence is zero.")
elif n == 1:
    print("the fibonacci in one sequence is one.")
else:
    a = 0
    b = 1

    for i in range(2, n + 1):
        a, b = b, a + b

    print("the fibonacci in ", n, " sequence is ", a)
