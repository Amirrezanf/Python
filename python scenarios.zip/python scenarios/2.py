import random

random_number = random.randint(1, 50)

print("guess a number between 1 and 50")

while True:
    guess = int(input("your guess: "))
    if guess < random_number:
        print("the guessed number is low")
    elif guess > random_number:
        print("the guessed number is high")
    else:
        print("congrats! you guessed the correct number.")
        break
