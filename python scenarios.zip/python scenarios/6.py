num = int(input("plz enter an integer: "))
sum = 0

if num < 0:
    num = -num

while num > 0:
    digit = num % 10
    sum += digit
    num //= 10

print("the sum of digits is:", sum)
