
names = input("plz enter names seprated by space: ")
list1 = names.split()

list1 = [name.strip() for name in list1]

scores = input("plz enter scores seprated by space: ")
list2 = scores.split()

list2 = [score.strip() for score in list2]

if len(list1) != len(list2):
    print("number of both lists do not match!")
else:
    dictionary = dict(zip(list1, list2))

    print("the created dictionary is:\n ", dictionary)
