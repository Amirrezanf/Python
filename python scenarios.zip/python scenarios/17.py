inputs = input("plz enter values of list separated by space: ")
lst = inputs.split()
lst = [item.strip() for item in lst]
unique = []

for item in lst:
    if item not in unique:
        unique.append(item)

print("a list with unique values:\n ", unique)

