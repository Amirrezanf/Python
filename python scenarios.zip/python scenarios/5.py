num = int(input("plz enter a number: "))
if num < 0:
    print("the number is negative!")
else:
    factorial = 1
    counter = 1

    while counter <= num:
        factorial *= counter
        counter += 1

    print("the factorial is:", factorial)
