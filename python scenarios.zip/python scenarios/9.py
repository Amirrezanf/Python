
sentence = input("plz enter a sentence: ")
words = sentence.split()

longest_word = ""
max_length = 0

for word in words:
    if len(word) > max_length:
        longest_word = word
        max_length = len(word)

print("the largest word is", longest_word)
