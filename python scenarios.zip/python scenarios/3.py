def finder(numbers):
    max = numbers[0]

    for number in numbers:
        if number > max:
            max = number
    return max

TestList = [5, 3, 7, 6, 8, -9, 4]
largest = finder(TestList)
print("largest number in list:", finder(TestList))
