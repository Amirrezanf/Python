def prime(n):
    if n <= 1:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

def LessPrimes(n):
    for num in range(2, n):
        if prime(num):
            print(num)

number = int(input("plz enter a positive integer: "))
print("the prime numbers less than: ")
LessPrimes(number)
